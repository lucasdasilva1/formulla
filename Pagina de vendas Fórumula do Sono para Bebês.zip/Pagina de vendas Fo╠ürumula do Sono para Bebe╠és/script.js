document.addEventListener('DOMContentLoaded', () => {
    // FAQ Accordion
    const faqQuestions = document.querySelectorAll('.faq-question');

    faqQuestions.forEach(question => {
        question.addEventListener('click', () => {
            const item = question.parentElement;

            // Close other items
            document.querySelectorAll('.faq-item').forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                }
            });

            // Toggle current item
            item.classList.toggle('active');
        });
    });

    // Smooth Scroll for Anchors
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Floating Sleep Emojis
function createFloatingEmoji() {
    const container = document.querySelector('.floating-emojis');
    if (!container) return;

    const emojis = ['💤', '😴', '🌙', '⭐'];
    const emoji = document.createElement('div');
    emoji.className = 'emoji';
    emoji.textContent = emojis[Math.floor(Math.random() * emojis.length)];

    // Random horizontal position
    emoji.style.left = Math.random() * 100 + '%';

    // Random animation duration (10-15 seconds) - slower
    emoji.style.animationDuration = (10 + Math.random() * 5) + 's';

    // Random delay
    emoji.style.animationDelay = Math.random() * 3 + 's';

    container.appendChild(emoji);

    // Remove emoji after animation completes
    setTimeout(() => {
        emoji.remove();
    }, 18000);
}

// Create emojis less frequently (every 2 seconds instead of 0.8s)
setInterval(createFloatingEmoji, 2000);

// Create smaller initial batch (4 instead of 8)
for (let i = 0; i < 4; i++) {
    setTimeout(createFloatingEmoji, i * 500);
}
